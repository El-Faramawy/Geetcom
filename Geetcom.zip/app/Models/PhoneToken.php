<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;


class PhoneToken extends Model
{
    protected $table ='phone_token';
    protected $guarded = [];

}
