@extends('layouts.admin.app')
@section('page_title') Fattura @endsection
@section('content')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body" id="print_div">
                    <div class="clearfix">
                        <div class="float-left">
                            <h3 class="card-title mb-0">#Fattura-{{$order->id}}</h3>
                        </div>
                        <div class="float-right">
                            <p class="mb-1"><span class="font-weight-bold">Data fattura :</span> {{date('d-m-Y', strtotime($order->created_at))}}</p>
                            <p class="mb-0"><span class="font-weight-bold">Utente :</span> {{$order->user->name??''}}</p>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-lg-6 ">
                            <p class="h3">Modulo fattura:</p>
                            <address>
                                <b>Sede : </b>  {{$order->branch->name_it ?? ''}}<br>
                                <b>Modalità di pagamento : </b> {{$order->pay_type =='cash'? 'Contanti' : 'In linea'}}
                            </address>
                        </div>
                        <div class="col-lg-6 text-right">
                            <p class="h3">Fattura:</p>
                            <address>
                                {{$order->address->recipient_name ?? ''}}<br>
                                {{$order->address->recipient_number ?? ''}}<br>
                                {{$order->address->address ?? ''}}
                            </address>
                        </div>
                    </div>
                    <div class="table-responsive push">
                        <table class="table table-bordered table-hover mb-0 text-nowrap">
                            <tbody>
                            <tr class=" ">
                                <th class="text-center"></th>
                                <th>menù</th>
                                <th class="text-center">QUANTITÀ</th>
                                <th class="text-right">Prezzo unitario</th>
                                <th class="text-right">Totale parziale</th>
                            </tr>
                            @foreach($order->order_details as $key=>$detail)
                                <tr>
                                    <td class="text-center">{{$key+1}}</td>
                                    <td>
                                        <p class="font-w600 mb-1">
                                            {{$detail->product?$detail->product->name ?? '':$detail->offer->name ?? ''}}
                                        </p>
                                        <div class="text-muted">
                                            @if($detail->additions)
                                                @foreach($detail->additions as $addition)
                                                    <div class="text-muted">
                                                        {{$addition->addition->name}} ( {{$addition->addition->price}} CHF )
                                                    </div>
                                                @endforeach
                                            @endif
                                        </div>
                                    </td>
                                    <td class="text-center">{{$detail->amount}}</td>
                                    <td class="text-right number-font1">{{$detail->price}} CHF</td>
                                    <td class="text-right number-font1">{{$detail->sub_total}} CHF</td>
                                </tr>
                            @endforeach
                            @if($order->coupon || $order->tips > 0)
                            <tr>
                                @if($order->coupon)
                                    <td colspan="3" class="font-weight-bold text-uppercase text-right">Codice coupon : {{$order->coupon->code}}
                                        @if($order->coupon->type == 'value')( {{$order->coupon->value}} CHF )
                                        @else '( {{$order->coupon->percentage}} % )'
                                        @endif
                                    </td>
                                    <td  class="font-weight-bold text-uppercase text-right">Tips</td>
                                @else
                                    <td colspan="4" class="font-weight-bold text-uppercase text-right">Tips</td>
                                @endif
                                <td class="font-weight-bold text-right h4 number-font1">{{$order->tips}} CHF</td>
                            </tr>
                            @endif
                            <tr>
                                <td colspan="4" class="font-weight-bold text-uppercase text-right">Totale</td>
                                <td class="font-weight-bold text-right h4 number-font1">{{$order->total}} CHF</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer text-right">
                    <button type="button" class="btn btn-danger mb-1" onclick="/*printClient('print_div');*/ javascript:window.print();"><i
                            class="fa fa-print"></i> Stampa fattura
                    </button>
                </div>
            </div>
        </div><!-- COL-END -->
    </div>
@endsection

@push('admin_js')
{{--    <script>--}}
{{--        function printClient(elem) {--}}
{{--            var mywindow = window.open('', 'PRINT', 'height=400,width=600');--}}
{{--            mywindow.document.write('<html><head>' +--}}
{{--                '<title>Ali Pizza</title>');--}}
{{--            mywindow.document.write('</head><body style="direction: ltr">');--}}
{{--            mywindow.document.write(document.getElementById(elem).innerHTML);--}}
{{--            mywindow.document.write('</body></html>');--}}

{{--            mywindow.document.close(); // necessary for IE >= 10--}}
{{--            mywindow.focus(); // necessary for IE >= 10*/--}}

{{--            mywindow.print();--}}
{{--            mywindow.close();--}}

{{--            return true;--}}
{{--        }--}}
{{--    </script>--}}
@endpush
