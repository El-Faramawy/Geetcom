
<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                حقوق النشر © جميع الحقوق محفوظة 2023 <a rel="stylesheet" target="_blank" > Geetcom </a>.
            </div>
        </div>
    </div>
</footer>
